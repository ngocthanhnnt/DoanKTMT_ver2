# Functions from the following NumPy document
# http://docs.scipy.org/doc/numpy/reference/routines.padding.html

# "NOQA" to suppress flake8 warning
from cupy.padding import pad  # NOQA
