# flake8: NOQA
# "flake8: NOQA" to suppress warning "H104  File contains nothing but comments"

# TODO(okuta): Implement iscomplex


# TODO(okuta): Implement iscomplexobj


# TODO(okuta): Implement isfortran


# TODO(okuta): Implement isreal


# TODO(okuta): Implement isrealobj
